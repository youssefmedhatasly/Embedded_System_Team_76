#ifndef LCD_H
#define LCD_H

#include <stdbool.h>
#include <stdint.h>

// I2C pin configuration for the LCD
#define LCD_I2C_SDA 12
#define LCD_I2C_SCL 13

// I2C address of the LCD (typical for many I2C LCD backpacks)
#define LCD_ADDR 0x27

// Public functions
void lcd_init();
void lcd_set_cursor(uint8_t line, uint8_t col);
void lcd_putc(char c);
void lcd_puts(const char *s);
void lcd_clear();

#endif // LCD_H
