#ifndef WATERLEVEL_H
#define WATERLEVEL_H
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"

#define WATER_SENSOR_PIN 27   // GPIO26 is ADC input 0
#define ADC_INPUT_CHANNEL 1   // ADC channel for GPIO26
#define MAX_ADC_VALUE 4095.0f // Adjust based on max sensor voltage

void water_level_init(void);
float read_water_level(void);

#endif