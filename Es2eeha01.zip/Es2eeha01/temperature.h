#ifndef TEMPERATURE_H
#define TEMPERATURE_H
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"

#define TEMPERATURE_SENSOR_PIN 4
#define ADC_INPUT_CHANNEL 0

void temperature_sensor_init(void);
int16_t read_temperature(void);

#endif