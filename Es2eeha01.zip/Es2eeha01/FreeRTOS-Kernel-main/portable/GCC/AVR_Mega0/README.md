This port has been moved to `portable/ThirdParty/Partner-Supported-Ports/GCC/AVR_Mega0` directory.
