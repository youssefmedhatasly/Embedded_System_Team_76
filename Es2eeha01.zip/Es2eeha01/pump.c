#include "pump.h"

void pump_init(void)
{
    // Set up IN1 for ON/OFF control
    gpio_init(PUMP_SWITCH);
    gpio_set_dir(PUMP_SWITCH, GPIO_OUT);
    gpio_put(PUMP_SWITCH, false); // Ensure pump is OFF initially

    gpio_set_function(PUMP_PMW_PIN, GPIO_FUNC_PWM);       // Set pin to PWM function
    uint slice_num = pwm_gpio_to_slice_num(PUMP_PMW_PIN); // Get the PWM slice number for the pin
    pwm_set_wrap(slice_num, 255);
    // Set the clock divider to control PWM frequency
    pwm_set_clkdiv(slice_num, 4.0f);
    pwm_set_enabled(slice_num, true);
}

// Set the pump strength (0-100%)
void pump_on(uint8_t strength)
{
    // Enable the pump by setting IN1 HIGH
    gpio_put(PUMP_SWITCH, true);

    if (strength > 100)
        strength = 100; // Clamp strength to a max of 100%

    uint slice_num = pwm_gpio_to_slice_num(PUMP_PMW_PIN);
    uint16_t duty_cycle = (uint16_t)((strength * 255) / 100); // Map strength (0-100%) to 8-bit duty cycle (0-255)

    pwm_set_chan_level(slice_num, pwm_gpio_to_channel(PUMP_PMW_PIN), duty_cycle);
}

// Turn off the pump
void pump_off(void)
{
    // Disable the pump by setting IN1 HIGH
    gpio_put(PUMP_SWITCH, false);

    uint slice_num = pwm_gpio_to_slice_num(PUMP_PMW_PIN);
    pwm_set_chan_level(slice_num, pwm_gpio_to_channel(PUMP_PMW_PIN), 0); // Set duty cycle to 0
}