#ifndef BUZZER_H
#define BUZZER_H
#include "pico/stdlib.h" //Pico SDK standard library, which provides access to functions for controlling hardware peripherals such as GPIO and sleep
#include <stdio.h>       //serial communication to print messages for debugging or interacting with the device.
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "hardware/pwm.h"

#define BUZZER_PIN 5

void buzzer_init(void);
void buzzer_on(void);
void buzzer_off(void);
void buzzer_trigger(uint8_t times, uint16_t delayMs);

void buzzer_pwm_init();
void buzzer_pwm(uint8_t strength);

#endif