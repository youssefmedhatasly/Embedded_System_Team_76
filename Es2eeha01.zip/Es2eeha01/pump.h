#ifndef PUMP_H
#define PUMP_H
#include "pico/stdlib.h" //Pico SDK standard library, which provides access to functions for controlling hardware peripherals such as GPIO and sleep
#include <stdio.h> //serial communication to print messages for debugging or interacting with the device.
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "hardware/pwm.h"

#define PUMP_PMW_PIN 15
#define PUMP_SWITCH 25





void pump_init(void);
void pump_on(uint8_t strength);
void pump_off(void);

#endif 