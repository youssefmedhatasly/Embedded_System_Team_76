#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#include "pico/stdlib.h"
#include "hardware/adc.h"

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

#include "moisture.h"
#include "waterlevel.h"
#include "temperature.h"
#include "lcd.h"
#include "buzzer.h"
#include "pump.h"

// Shared variables
uint16_t moisture_level = 0;
float water_level = 0.0;
int16_t temperature = 0;
bool fillingPot = false;
// Mutex for shared variables
SemaphoreHandle_t xMutex;

// FreeRTOS Hooks
void vApplicationMallocFailedHook(void)
{
    taskDISABLE_INTERRUPTS();
    printf("Malloc failed!\n");
    for (;;)
    {
    }
}

void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    printf("Stack overflow in task: %s\n", pcTaskName);
    taskDISABLE_INTERRUPTS();
    for (;;)
    {
    }
}

// Task: Monitor Temperature (just read and store, no LCD printing here)
void vTemperatureTask(void *pvParameters)
{
    while (1)
    {
        if (xSemaphoreTake(xMutex, portMAX_DELAY))
        {
            temperature = read_temperature();
            xSemaphoreGive(xMutex);
        }
        vTaskDelay(pdMS_TO_TICKS(2000)); // Update every 2 seconds
    }
}

// Task: Monitor Water Level and Control Buzzer
void vWaterLevelTask(void *pvParameters)
{
    while (1)
    {
        if (xSemaphoreTake(xMutex, portMAX_DELAY))
        {
            water_level = read_water_level();
            xSemaphoreGive(xMutex);
        }

        // If water level is low, turn on the buzzer
        if (water_level < 35.0)
        {
            buzzer_trigger(5, 300); // 5 beeps, 300ms each
        }

        vTaskDelay(pdMS_TO_TICKS(5000)); // Check every 5 seconds
    }
}

// Task: Monitor Moisture Level and Control Pump
// If moisture <30, run pump at strength 70 for 3s, then off
void vMoistureTask(void *pvParameters)
{
    while (1)
    {
        if (xSemaphoreTake(xMutex, portMAX_DELAY))
        {
            moisture_level = get_moisture_level();
            xSemaphoreGive(xMutex);
        }

        // If moisture is low, pump on at 70% for 3s
        if (moisture_level < 40 && water_level > 35)
        {
            fillingPot = true;
        }
        if (fillingPot && water_level > 35)
        {
            if (moisture_level > 55)
            {
                fillingPot = false;
                pump_off();
            }
            else
            {
                if (moisture_level < 45)
                {
                    pump_on(90);
                    vTaskDelay(pdMS_TO_TICKS(5000)); // Pump on for 3 seconds
                    pump_off();
                }
                else
                {
                    pump_on(70);
                    vTaskDelay(pdMS_TO_TICKS(5000)); // Pump on for 3 seconds
                    pump_off();
                }
            }
        }
    }

    vTaskDelay(pdMS_TO_TICKS(8000)); // Check every 7 seconds
}

// Task: Display Temperature, Moisture, Water Level on LCD
void vDisplayTask(void *pvParameters)
{
    // Variables to hold local copies of sensor data
    uint16_t local_moisture;
    float local_water;
    int16_t local_temp;

    // Variable to manage flashing state
    bool flash_state = false;

    while (1)
    {
        // Copy shared variables under mutex
        if (xSemaphoreTake(xMutex, portMAX_DELAY))
        {
            local_moisture = moisture_level;
            local_water = water_level;
            local_temp = temperature;
            xSemaphoreGive(xMutex);
        }

        // Clear the LCD before updating
        lcd_clear();

        // First Line: Temperature or "FILL WATER"
        lcd_set_cursor(0, 0);
        if (local_water < 35.0)
        {
            // Flash "FILL WATER"
            if (flash_state)
            {
                lcd_puts("FILL WATER");
            }
            else
            {
                lcd_puts("          "); // Clear the line
            }

            // Toggle flash state for next cycle
            flash_state = !flash_state;
        }
        else
        {
            // Display Temperature
            char temp_str[16];
            snprintf(temp_str, sizeof(temp_str), "Temp:%dC      ", local_temp);
            lcd_puts(temp_str);
        }

        // Second Line: Moisture Level
        lcd_set_cursor(1, 0);
        char moisture_str[16];
        snprintf(moisture_str, sizeof(moisture_str), "Moisture:%d%%", local_moisture);
        lcd_puts(moisture_str);

        // Adjust the delay based on whether flashing is needed
        if (local_water < 20.0)
        {
            // Flashing interval (e.g., toggle every 500ms)
            vTaskDelay(pdMS_TO_TICKS(500));
        }
        else
        {
            // Normal update interval
            vTaskDelay(pdMS_TO_TICKS(2000));
        }
    }
}

int main()
{
    // Initialize hardware and peripherals
    stdio_init_all();
    adc_init();

    water_level_init();
    water_moisture_init();
    temperature_sensor_init();
    lcd_init();
    buzzer_init();
    pump_init();

    // Create mutex
    xMutex = xSemaphoreCreateMutex();

    if (xMutex != NULL)
    {
        // Create tasks
        xTaskCreate(vTemperatureTask, "Temperature Task", 256, NULL, 1, NULL);
        xTaskCreate(vWaterLevelTask, "Water Level Task", 256, NULL, 1, NULL);
        xTaskCreate(vMoistureTask, "Moisture Task", 256, NULL, 1, NULL);
        xTaskCreate(vDisplayTask, "Display Task", 256, NULL, 1, NULL);

        // Start scheduler
        vTaskStartScheduler();
    }

    // If we ever reach here, something went wrong
    for (;;)
    {
    }
    return 0;
}
