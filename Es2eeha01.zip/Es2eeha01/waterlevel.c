#include "waterlevel.h"
void water_level_init(void)
{
    adc_gpio_init(WATER_SENSOR_PIN);

    printf("Water Sensor Initialized.\n");
}

float calculate_percentage(uint16_t raw_adc_value)
{
    float percentage = 0.0f;

    if (raw_adc_value <= 1000)
    {
        // Segment 1: 1600 to 2100
        percentage = 0.06f * raw_adc_value - 96.0f;
    }
    else if (raw_adc_value <= 3000)
    {
        // Segment 2: 2100 to 3000
        percentage = 0.0778f * raw_adc_value - 100.38f;
    }
    else
    {
        // Cap at 100% for any value above 3000
        percentage = 100.0f;
    }

    // Clamp to 0-100 range
    if (percentage < 0)
        percentage = 0.0f;
    if (percentage > 100)
        percentage = 100.0f;

    return percentage;
}

float read_water_level(void)
{
    adc_select_input(ADC_INPUT_CHANNEL);

    // Read the raw ADC value (0–4095)
    uint16_t raw_adc_value = adc_read();
    printf("Raw Water Level: %u", raw_adc_value);
    // Scale to a level (e.g., 0–100 for percentage)

    // float water_level_percentage = (raw_adc_value * 100.0f) / MAX_ADC_VALUE;
    float water_level_percentage = calculate_percentage(raw_adc_value);
    printf("Water Level: %f\n", water_level_percentage);

    // For this example, return the percentage
    return water_level_percentage;
}