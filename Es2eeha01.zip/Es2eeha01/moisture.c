#include "moisture.h"
#include <stdio.h>
#include "hardware/adc.h"

// Function to initialize the GPIO pin for the moisture sensor
void water_moisture_init(void)
{
    adc_gpio_init(ES2EEHA_WATER_SENSOR_PIN);
    printf("Moisture Sensor Initialized.\n");
}

// Function to get the moisture level as a percentage
uint16_t get_moisture_level(void)
{
    // Select the appropriate ADC channel for the moisture sensor
    adc_select_input(WATER_PIN_ANALOGUE);

    // Read the raw ADC value (0–4095 for 12-bit resolution)
    uint16_t raw_adc_value = adc_read();

    // Debug: Print the raw ADC value

    // Convert raw ADC value to moisture level percentage (0–100)
    uint16_t moisture_level_percentage = ((4095 - raw_adc_value) * 100) / 4095;
    printf("Moisture Level: %u\n", raw_adc_value);

    // Return the moisture level as a percentage
    return moisture_level_percentage;
}
