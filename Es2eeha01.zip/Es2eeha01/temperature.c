#include "temperature.h"
#include <stdio.h> // For debug logging using printf

void temperature_sensor_init(void)
{
    // Enable the internal temperature sensor
    adc_set_temp_sensor_enabled(true);

    // Select the internal temperature sensor channel (ADC4)
}

int16_t read_temperature(void)
{
    adc_select_input(4);

    // Take multiple ADC samples and average them
    uint32_t sum = 0;
    int num_samples = 10;

    for (int i = 0; i < num_samples; i++)
    {
        sum += adc_read();
    }

    uint16_t raw_adc_value = sum / num_samples;

    // Debug: Print the raw ADC value

    // Convert raw ADC value to voltage (assuming 12-bit ADC)
    float voltage = raw_adc_value * 3.3f / 4095.0f;

    // Debug: Print the voltage

    // Convert voltage to temperature (RP2040 formula) without initial calibration offset
    float temperature = 27.0f - (voltage - 0.706f) / 0.001721f;

    // Debug: Print the calculated temperature
    printf("Temperature: %.2f°C\n", temperature);

    // Convert float to int16_t for return
    return (int16_t)temperature;
}
