#include "lcd.h"
#include "pico/stdlib.h"
#include "hardware/i2c.h"

// I2C parameters
#define I2C_PORT i2c0

// PCF8574 -> LCD pin mapping
#define LCD_BACKLIGHT 0x08 // P3
#define LCD_ENABLE 0x04    // P2
#define LCD_RW 0x02        // P1 (kept low for write)
#define LCD_RS 0x01        // P0

static void lcd_i2c_write(uint8_t data)
{
    i2c_write_blocking(I2C_PORT, LCD_ADDR, &data, 1, false);
}

static void lcd_pulse_enable(uint8_t data)
{
    lcd_i2c_write(data | LCD_ENABLE | LCD_BACKLIGHT);
    sleep_us(1);
    lcd_i2c_write((data & ~LCD_ENABLE) | LCD_BACKLIGHT);
    sleep_us(50);
}

static void lcd_send_nibble(uint8_t nibble, bool is_data)
{
    uint8_t data = (nibble & 0x0F) << 4;
    if (is_data)
    {
        data |= LCD_RS;
    }
    // R/W is always low
    lcd_pulse_enable(data);
}

static void lcd_send_byte(uint8_t byte, bool is_data)
{
    lcd_send_nibble(byte >> 4, is_data);
    lcd_send_nibble(byte & 0x0F, is_data);
}

static void lcd_command(uint8_t cmd)
{
    lcd_send_byte(cmd, false);
    if (cmd == 0x01 || cmd == 0x02)
    {
        // Clear or home commands require longer delays
        sleep_ms(2);
    }
    else
    {
        sleep_us(50);
    }
}

void lcd_init()
{
    // Initialize the I2C for LCD here for convenience
    i2c_init(I2C_PORT, 400 * 1000);
    gpio_set_function(LCD_I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(LCD_I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(LCD_I2C_SDA);
    gpio_pull_up(LCD_I2C_SCL);

    sleep_ms(50); // Wait for LCD to power up

    // Initialize LCD in 4-bit mode as per standard procedure
    lcd_send_nibble(0x03, false);
    sleep_ms(5);
    lcd_send_nibble(0x03, false);
    sleep_us(150);
    lcd_send_nibble(0x03, false);
    sleep_ms(5);
    lcd_send_nibble(0x02, false);
    sleep_us(50);

    // 4-bit mode, 2 lines, 5x8 font
    lcd_command(0x28);
    // Display on, no cursor, no blink
    lcd_command(0x0C);
    // Clear display
    lcd_command(0x01);
    // Entry mode: Increment, no shift
    lcd_command(0x06);
}

void lcd_set_cursor(uint8_t line, uint8_t col)
{
    uint8_t addr = (line == 0) ? (0x80 + col) : (0xC0 + col);
    lcd_command(addr);
}

void lcd_putc(char c)
{
    lcd_send_byte((uint8_t)c, true);
}

void lcd_puts(const char *s)
{
    while (*s)
    {
        lcd_putc(*s++);
    }
}

void lcd_clear()
{
    lcd_command(0x01);
    sleep_ms(2);
}
