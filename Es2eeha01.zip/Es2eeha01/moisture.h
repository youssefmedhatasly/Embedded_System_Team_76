#ifndef MOISTURE_H
#define MOISTURE_H
#include "pico/stdlib.h" //Pico SDK standard library, which provides access to functions for controlling hardware peripherals such as GPIO and sleep
#include <stdio.h>       //serial communication to print messages for debugging or interacting with the device.
#include "hardware/gpio.h"
#include "hardware/adc.h"

#define ES2EEHA_WATER_SENSOR_PIN 28
#define WATER_PIN_ANALOGUE 2

void water_moisture_init(void);
uint16_t get_moisture_level(void);

#endif