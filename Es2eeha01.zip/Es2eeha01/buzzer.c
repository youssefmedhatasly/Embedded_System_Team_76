#include "buzzer.h"

void buzzer_init(void)
{
    gpio_init(BUZZER_PIN);              // initialise
    gpio_set_dir(BUZZER_PIN, GPIO_OUT); // ddr
}

void buzzer_on(void)
{
    gpio_put(BUZZER_PIN, true);
}

void buzzer_off(void)
{
    gpio_put(BUZZER_PIN, false);
}

// Trigger the buzzer with a pattern
void buzzer_trigger(uint8_t times, uint16_t delayMs)
{
    for (int i = 0; i < times; i++)
    {
        buzzer_on();
        sleep_ms(delayMs);
        buzzer_off();
        sleep_ms(delayMs); // Optional: Add a delay between buzzes
    }
}

void buzzer_pwm_init(void)
{
    gpio_set_function(BUZZER_PIN, GPIO_FUNC_PWM);       // Set pin to PWM function
    uint slice_num = pwm_gpio_to_slice_num(BUZZER_PIN); // Get the PWM slice number for the pin
    pwm_set_wrap(slice_num, 255);
    // Set the clock divider to control PWM frequency
    pwm_set_clkdiv(slice_num, 4.0f);
    pwm_set_enabled(slice_num, true);
}

// Set the buzzer strength (0-100%)
void buzzer_pwm(uint8_t strength)
{
    if (strength > 100)
        strength = 100; // Clamp strength to a max of 100%

    uint slice_num = pwm_gpio_to_slice_num(BUZZER_PIN);
    uint16_t duty_cycle = (uint16_t)((strength * 255) / 100); // Map strength (0-100%) to 8-bit duty cycle (0-255)

    pwm_set_chan_level(slice_num, pwm_gpio_to_channel(BUZZER_PIN), duty_cycle);
}
